﻿using UnityEngine;
using System.Collections;

public class BordManager : MonoBehaviour
{
    public Transform[] Models; //De array is public zodat je de modellen in de editor kan toevoegen. 
    // Er zijn andere, "betere", manieren om een array van Transforms te vullen.
    // Probeer uit te vinden hoe het anders kan.

    void Awake()
    {
        // Awake is een standaard methode van MonoBehaviour. Deze word gedraaid als alles aan het opstarten is.
        //Je kan deze gebruiken om bijvoorbeeld variablen te zetten of methodes te draaien die nodig zijn voor het spel.
    }

    private void CreateBoard()
    {
        //Zet hier alle code om het spelbord op te bouwen. Het is verstandig om dit in verschillende methodes op te delen.
        /* 
        - Zorg dat je 2 kaarten van iedere variant maakt.
        - Plaats alle kaarten op de juiste positie. Hiervoor kan je een genestelde For loop gebruiken.
        - Zorg dat alle kaarten "geschud" worden zodat ze niet bij ieder spel op dezelfde plaats staan.
        */
    }

   
    private int CheckWhichObjectClicked(Vector3 hitLocation)
    {
        //Om bij het vak SE12 te blijven, gebruiken we een class "Kaart" zonder Monobehaviour.
        //Je kan daarom geen 'getcomponent' gebruiken om uit te vinden wel object je aanklikt.
        //Verzin daarom een andere manier om dit te achterhalen.
        return 0;
    }

    private IEnumerator CheckIfCardsMatch()
    {
       //Zet hier de code om te checken of de kaarten die je aanklikte hetzelfde zijn.
       //Probeer de code voor deze check zoveel mogelijk in de "kaart" class te zetten.
        yield return new WaitForSeconds(1);
    }

    void Update()
    {
       //Update is ook een standaard methode van monobehaviour. Deze draait ieder frame 1 keer. Als je 60 fps heb draait deze methode dus 60 keer per seconde.
       //Zet hier al je code om input te registreren. In dit geval dus het aanklikken van een kaart. 
    }

    private void AddScoreAndCheckIfFinished()
    {
        //Verzin wat leuke manieren om te scoren in het spel.
        //Zorg ook dat als een setje kaartje bij elkaar hebt gevonden, gecheckt wordt of je misschien al alles gevonden hebt.
    }

  
}

