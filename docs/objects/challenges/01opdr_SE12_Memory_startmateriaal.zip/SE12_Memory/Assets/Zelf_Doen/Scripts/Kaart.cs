﻿using UnityEngine;
using System.Collections;

public class Kaart
{
   //Zorg dat je nette class maakt zoals je bij SE12/OIS geleerd hebt.
   //Maak een constructor, getters,setters etc.

    public IEnumerator FlipCard()
    { 
        //Zet hier de code om de kaart om te draaien. 
        yield return null;
    }

    public IEnumerator MoveToPosition(Vector3 endPosition)
    {
        //Zet hier de code om de kaart naar een positie te verplaatsen.
        yield return null;
    }


    public static bool CheckIfMachingPair(Card card1, Card card2)
    {
        //Check hier of de kaarten een match zijn.
        return true;
    }

}
