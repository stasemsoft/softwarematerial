﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager instance;

    private Text Score;
    private Text WinText;
    private Animator WT_anim;

	// Use this for initialization
	void Awake ()
    {
        instance = this;
        Score = GameObject.Find("Score").GetComponent<Text>();
        WinText = GameObject.Find("WinText").GetComponent<Text>();

        WT_anim = WinText.GetComponent<Animator>();
        WT_anim.enabled = false;
    }
	
	public void UpdateScoreText ()
    {
        Score.text = BoardManager.instance.getScore.ToString("D3");
	}

    public void WinGameAnimation()
    {
        WT_anim.enabled = true;
        WT_anim.Play("WinText");
    }
}
