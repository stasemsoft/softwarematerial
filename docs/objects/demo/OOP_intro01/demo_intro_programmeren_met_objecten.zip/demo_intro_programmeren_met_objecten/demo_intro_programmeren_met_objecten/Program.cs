﻿using System;

namespace demo_intro_programmeren_met_objecten
{
    class Program
    {




        static void Main(string[] args)
        {
            Character hero = new Character(100);
            Character enemy1 = new Character(42);
            Character enemy2 = new Character(13);

            // status
            Console.WriteLine("Status:");
            Console.WriteLine(" hero: "+hero.HitPoints);
            Console.WriteLine(" enemy1: "+enemy1.HitPoints);
            Console.WriteLine(" enemy2: "+enemy2.HitPoints);

            // heal
            enemy1.Heal(5, enemy2);
            hero.Heal(3, enemy1);

        }






    }
}
