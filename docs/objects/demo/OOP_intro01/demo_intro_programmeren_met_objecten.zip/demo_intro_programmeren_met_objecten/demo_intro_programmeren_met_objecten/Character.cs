﻿using System;
namespace demo_intro_programmeren_met_objecten
{
    public class Character
    {


        // properties   ( 'propg'+tab tab )
        public int HitPoints
        {
            get;
            private set;
        }


        // constructor ( 'ctor' + tab tab )
        public Character(int initialHitPoints)
        {
            this.HitPoints = initialHitPoints;
        }


        // methods
        public void Heal(int amount, Character otherCharacter)
        {
            this.HitPoints -= amount;
            otherCharacter.GetHealed(2 * amount);
        }


        public void GetHealed(int amount)
        {
            this.HitPoints +=  amount;
        }


    }
}
