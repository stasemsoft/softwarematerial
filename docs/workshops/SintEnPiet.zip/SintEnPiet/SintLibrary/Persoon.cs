﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SintLibrary
{
    public class Persoon
    {

        // Field
        private List<Schoen> schoenen;

        // properties
        public string Naam { 
            get; 
            private set; 
        }

        // constructors
        public Persoon(string naam)
        {
            this.Naam = naam;
            this.schoenen = new List<Schoen>();
        }

        // methods
        public void VoegSchoenToe(Schoen schoen)
        {
            this.schoenen.Add(schoen);
        }



    }
}
