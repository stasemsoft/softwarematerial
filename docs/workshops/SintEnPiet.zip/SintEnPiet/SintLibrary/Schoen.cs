﻿using System;
using System.Collections.Generic;

namespace SintLibrary
{
    public class Schoen
    {

        private List<Cadeau> cadeaus = new List<Cadeau>();

        public Schoen()
        {

        }

        public void StopCadeauErIn(Cadeau cadeau)
        {
            this.cadeaus.Add(cadeau);
        }
    }
}
