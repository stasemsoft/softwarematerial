﻿namespace SintLibrary
{
    public class Cadeau
    {

        public string Omschrijving { get; private set; }

        public Cadeau(string omschrijving)
        {
            this.Omschrijving = omschrijving;
        }

    }
}