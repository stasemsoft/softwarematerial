﻿using System;
using System.Collections.Generic;
using SintLibrary;

namespace Sint
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            List<Persoon> personen = new List<Persoon>();
            personen.Add(new Persoon("Abraham"));
            personen.Add(new Persoon("Babs"));

            List<Cadeau> cadeaus = new List<Cadeau>();
            cadeaus.Add(new Cadeau("Racefiets"));
            cadeaus.Add(new Cadeau("Zak snoep"));
            cadeaus.Add(new Cadeau("Bromtol"));

            foreach (Persoon persoon in personen)
            {
                Schoen schoen = new Schoen();
                persoon.VoegSchoenToe(schoen);
                schoen.StopCadeauErIn( cadeaus[0] );  // todo: met dat cadeau is neit zo mooi!!
                cadeaus.Remove(0);
            }

            Console.ReadLine();
        }
    }
}
