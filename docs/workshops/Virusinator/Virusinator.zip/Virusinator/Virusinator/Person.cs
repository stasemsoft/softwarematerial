﻿using System;
using System.Collections.Generic;

namespace Virusinator
{
    internal class Person
    {

     

        public bool IsInfected
        {
            get { return viruses.Count > 0 ; }
        }

        private List<Virus> viruses = new List<Virus>();

        public Virus MyVirus
        {
            get { return this.viruses[0]; }
        }


        internal void InfectWith(Virus virus)
        {
            this.viruses.Add(virus);
        }


    }
}