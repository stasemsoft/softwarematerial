﻿using System;

namespace Virusinator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello virus modelleerinators!");

            const int numInhabitants = 50;   
            Country country = new Country("Virusland", numInhabitants);
            Console.WriteLine(country);

            Virus virus = new Virus("N1H13");
            country.InfectPersons(1, virus);    // <-- magic number!! Not done!
            Console.WriteLine(country);

            for (int i = 0; i < 10; i++)
            {
                country.NextStepInInfections();
                Console.WriteLine(country);
            }


            Console.ReadLine();
        }
    }
}
