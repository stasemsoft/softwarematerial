﻿namespace Virusinator
{
    internal class Virus
    {

        public Virus(string code)
        {
            this.Code = code;

        }

        public string Code { get; }

    }
}