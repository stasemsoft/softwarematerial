﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Virusinator
{
    internal class Country
    {

        public string Name
        {
            get;
            private set;
        }


        private List<Person> persons = new List<Person>();
        static private Random random = new Random();


        // ctor
        public Country(string name, int numberOfInhabitants)
        {
            this.Name = name;
            for (int i = 0; i < numberOfInhabitants; i++)
            {
                this.persons.Add(new Person());
            }
        }

        internal void NextStepInInfections()
        {
            foreach (var person in this.persons)
            {
                if (person.IsInfected)
                {
                    this.InfectPersons(2, person.MyVirus);
                }
            }
        }


        internal void InfectPersons(int numberOfPersonsToBeInfected, Virus virus)
        {
            for (int i = 0; i < numberOfPersonsToBeInfected; i++)
            {
                InfectPersons(virus);
            }
        }


        private void InfectPersons(Virus virus)
        {
            this.RandomPerson().InfectWith(virus);
        }


        private Person RandomPerson()
        {
            return this.persons[random.Next(this.persons.Count)];
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder
                .Append(this.Name)
                .Append(": ");
            foreach (var person in this.persons)
            {
                stringBuilder.Append( person.IsInfected ? "*"  : "." );
            }
            return stringBuilder.ToString();
        }

    }
}