﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Crossing
{
    public class Crossing
    {



        // Field : keep it PRIVATE! No capital. 
        private string name;
        private List<TrafficLight> trafficLights;
        



        // ctor
        public Crossing(string crossingName)
        {
            this.name = crossingName;
            trafficLights = new List<TrafficLight>();
        }


        // methods
        internal Crossing NotGreenTogether(char cue1, char cue2)
        {
            foreach (var trafficLight in this.trafficLights)
            {
                if (trafficLight.Cue == cue1)
                    { trafficLight.NotGreenTogetherWith(this.TrafficLightWithCue(cue2)); }
                if (trafficLight.Cue == cue2)
                    { trafficLight.NotGreenTogetherWith(this.TrafficLightWithCue(cue1)); }
            }
            return this;
        }


        private TrafficLight TrafficLightWithCue(char cue)
        {
            foreach (var light in this.trafficLights)
            {
                if (light.Cue == cue)
                {
                    return light;
                }
            }
            // no TrafficLight found with this cue...
            throw new Exception("No TrafficLight in this Crossing has cue " + cue);
        }


        internal void ApplyAction(char keyChar)
        {
            foreach (var light in this.trafficLights)
            {
                if (light.Cue == keyChar)
                {
                    light.GoGreen();
                }
            }
        }


        public Crossing AddTrafficLight(char cue)
        {
            this.trafficLights.Add(new TrafficLight(cue));
            return this;
        }


        public override string ToString()
        {
            StringBuilder output = new StringBuilder();
            output.AppendLine(this.name);
            foreach (var trafficLight in this.trafficLights)
            {
                output.AppendLine("\t"+trafficLight.ToString());
            }
            return output.ToString();
        }



    }
}
