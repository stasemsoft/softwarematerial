﻿using System;
namespace Crossing
{


    public enum TLColor { Red, Orange, Green }


}
