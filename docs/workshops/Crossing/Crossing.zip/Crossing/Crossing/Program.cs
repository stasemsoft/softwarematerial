﻿using System;

namespace Crossing
{
    class Program
    {



        static void Main(string[] args)
        {
            Console.WriteLine("Hello T'raffic World!");
            Crossing crossing
                = new Crossing("Ring/Montgomerylaan")
                    .AddTrafficLight('a')
                    .AddTrafficLight('b')
                    .AddTrafficLight('c')
                    .NotGreenTogether('a','b')
                    .NotGreenTogether('a','c');
            
            Console.WriteLine(crossing);
            ConsoleKeyInfo key = Console.ReadKey();
            char lastKey = '@'; 
            while (key.KeyChar != 'q')
            {
                if (lastKey != key.KeyChar)
                {
                    lastKey = key.KeyChar;
                    Console.WriteLine(key.KeyChar);
                    crossing.ApplyAction(key.KeyChar);
                    Console.WriteLine(crossing);
                }
                key = Console.ReadKey();
            }
        }



        


    }
}
