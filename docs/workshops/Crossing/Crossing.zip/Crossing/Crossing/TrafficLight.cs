﻿using System;
using System.Collections.Generic;


namespace Crossing
{
    internal class TrafficLight
    {

        //liefst:
        List<TrafficLight> notTogether = new List<TrafficLight>();
        // maar voor nu:
        //NOT ANY MORE: List<char> notTogetherTemp = new List<char>();
        // propg
        public TLColor Color
        {
            get;
            private set;
        }


        public char Cue
        {
            get;
            private set;
        }



        // ctor 
        public TrafficLight(char myCue)
        {
            this.Color = TLColor.Red;
            this.Cue = myCue;
        }


        internal void NotGreenTogetherWith(TrafficLight trafficLight)
        {
            notTogether.Add(trafficLight);
        }


        public override string ToString()
        {
            return String.Format("TrafficLight: {0} is now {1}", this.Cue, this.Color);
        }


        internal void GoGreen()
        {
            // tobe checked if another TL is still Green!
            foreach (var light  in this.notTogether)
            {
                light.DontBeGreenAnymore();
            }
            this.Color = TLColor.Green;
        }


        private void DontBeGreenAnymore()
        {
            if (this.Color == TLColor.Green)
            {
                this.Color = TLColor.Orange;
            }
            if (this.Color == TLColor.Orange)
            {
                this.Color = TLColor.Red;
            }
        }


    }
}